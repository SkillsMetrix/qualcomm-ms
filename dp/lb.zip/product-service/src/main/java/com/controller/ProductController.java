package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Product;
import com.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	private ProductService service;
	@Value("${product.message}")
	String message;
	
	@PostMapping("/addproduct")
	public List<Product> addProducts(@RequestBody List<Product> prolist){
		return service.addProduct(prolist);
	}
	@GetMapping("/loadproducts")
	public List<Product> loadProducts(){
		System.out.println(message);
		return service.getProducts();
	}
	@GetMapping("/loadproductsbyid/{plist}")
	public List<Product> getProById(@PathVariable List<Long> plist){
		return service.getProductByIds(plist);
	}

}
