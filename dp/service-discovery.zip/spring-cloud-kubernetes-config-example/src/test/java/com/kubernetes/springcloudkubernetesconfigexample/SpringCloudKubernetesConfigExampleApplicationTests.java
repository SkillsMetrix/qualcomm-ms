package com.kubernetes.springcloudkubernetesconfigexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudKubernetesConfigExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
