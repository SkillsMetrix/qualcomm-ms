package com.kubernetes.springcloudkubernetesserverexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudKubernetesServerExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudKubernetesServerExampleApplication.class, args);
	}

}
