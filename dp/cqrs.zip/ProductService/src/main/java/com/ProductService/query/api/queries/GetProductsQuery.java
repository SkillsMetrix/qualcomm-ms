package com.ProductService.query.api.queries;

public class GetProductsQuery {
}
